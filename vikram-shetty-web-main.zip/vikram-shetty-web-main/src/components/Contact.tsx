import { Phone, Mail, Linkedin, Github, MapPin, Send } from 'lucide-react';
import Button from './Button';

const Contact = () => {
  const contactInfo = [
    {
      icon: <Phone className="w-5 h-5" />,
      label: "Phone",
      value: "9008641682",
      href: "tel:+919008641682"
    },
    {
      icon: <Mail className="w-5 h-5" />,
      label: "Email", 
      value: "shetty263e@gmail.com",
      href: "mailto:shetty263e@gmail.com"
    },
    {
      icon: <Linkedin className="w-5 h-5" />,
      label: "LinkedIn",
      value: "vikram-shetty-2b87a6327",
      href: "https://www.linkedin.com/in/vikram-shetty-2b87a6327"
    },
    {
      icon: <Github className="w-5 h-5" />,
      label: "GitHub",
      value: "vikramshetty-26", 
      href: "https://github.com/vikramshetty-26"
    }
  ];

  const handleDownloadResume = () => {
    // In a real app, this would download the actual PDF
    const link = document.createElement('a');
    link.href = '#';
    link.download = 'Vikram_Shetty_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadCertificates = () => {
    // In a real app, this would download the actual PDF
    const link = document.createElement('a');
    link.href = '#';
    link.download = 'Vikram_Shetty_Certificates.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          
          {/* Section Header */}
          <div className="text-center fade-in-up mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Get In <span className="gradient-text">Touch</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-accent mx-auto rounded-full"></div>
            <p className="text-lg text-muted-foreground mt-6 max-w-2xl mx-auto">
              Ready to collaborate on exciting projects or discuss opportunities? 
              I'd love to hear from you!
            </p>
          </div>
          
          {/* Contact Grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            
            {/* Contact Information */}
            <div className="fade-in-left">
              <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
                <h3 className="text-2xl font-semibold mb-6 text-foreground">
                  Contact Information
                </h3>
                
                <div className="space-y-4">
                  {contactInfo.map((contact, index) => (
                    <a
                      key={index}
                      href={contact.href}
                      target={contact.label === 'LinkedIn' || contact.label === 'GitHub' ? '_blank' : undefined}
                      rel={contact.label === 'LinkedIn' || contact.label === 'GitHub' ? 'noopener noreferrer' : undefined}
                      className="flex items-center gap-4 p-4 bg-secondary/50 rounded-lg hover:bg-secondary transition-colors duration-200 group"
                    >
                      <div className="p-2 bg-accent/10 text-accent rounded-lg group-hover:bg-accent group-hover:text-accent-foreground transition-colors duration-200">
                        {contact.icon}
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">
                          {contact.label}
                        </div>
                        <div className="font-medium text-foreground">
                          {contact.value}
                        </div>
                      </div>
                    </a>
                  ))}
                </div>
                
                {/* Location */}
                <div className="mt-6 p-4 bg-secondary/50 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-accent/10 text-accent rounded-lg">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Location</div>
                      <div className="font-medium text-foreground">Karnataka, India</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Quick Message */}
            <div className="fade-in-right">
              <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
                <h3 className="text-2xl font-semibold mb-6 text-foreground">
                  Quick Message
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Name
                    </label>
                    <input 
                      type="text"
                      className="w-full px-4 py-3 bg-secondary border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-accent transition-colors duration-200"
                      placeholder="Your name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Email
                    </label>
                    <input 
                      type="email"
                      className="w-full px-4 py-3 bg-secondary border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-accent transition-colors duration-200"
                      placeholder="your.email@example.com"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">
                      Message
                    </label>
                    <textarea 
                      rows={4}
                      className="w-full px-4 py-3 bg-secondary border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-accent transition-colors duration-200 resize-none"
                      placeholder="Your message..."
                    ></textarea>
                  </div>
                  
                  <Button 
                    size="lg" 
                    className="w-full"
                    icon={<Send size={20} />}
                  >
                    Send Message
                  </Button>
                </div>
              </div>
            </div>
            
          </div>
          
          {/* Download Section */}
          <div className="fade-in-up">
            <div className="bg-gradient-accent rounded-xl p-8 text-center shadow-xl">
              <h3 className="text-2xl font-bold text-accent-foreground mb-3">
                Download My Documents
              </h3>
              <p className="text-accent-foreground/90 mb-6">
                Get my latest resume and certificates
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  variant="secondary" 
                  size="lg" 
                  onClick={handleDownloadResume}
                  icon={<Send size={20} />}
                >
                  Download Resume
                </Button>
                <Button 
                  variant="secondary" 
                  size="lg" 
                  onClick={handleDownloadCertificates}
                  icon={<Send size={20} />}
                >
                  Download Certificates
                </Button>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};

export default Contact;