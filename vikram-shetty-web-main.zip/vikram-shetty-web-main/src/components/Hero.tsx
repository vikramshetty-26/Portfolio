import { Download, FileText, Award } from 'lucide-react';
import Button from './Button';
const vikramProfile = '/lovable-uploads/cb69424f-6ac7-4701-bfa1-e9ddbed7940c.png';

const Hero = () => {
  const handleDownloadResume = () => {
    // In a real app, this would download the actual PDF
    const link = document.createElement('a');
    link.href = '#';
    link.download = 'Vikram_Shetty_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadCertificates = () => {
    // In a real app, this would download the actual PDF
    const link = document.createElement('a');
    link.href = '#';
    link.download = 'Vikram_Shetty_Certificates.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 hero-pattern"></div>
      
      <div className="container mx-auto px-6 py-20 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            
            {/* Text Content */}
            <div className="space-y-8 fade-in-up">
              <div className="space-y-4">
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold">
                  <span className="text-foreground">Hi, I'm </span>
                  <span className="gradient-text">Vikram Shetty</span>
                </h1>
                <div className="text-xl md:text-2xl text-muted-foreground space-y-2">
                  <p>Aspiring <span className="text-accent font-semibold">MERN Stack Developer</span></p>
                  <p><span className="text-accent font-semibold">Full Stack Engineer</span></p>
                </div>
              </div>
              
              <p className="text-lg text-muted-foreground max-w-2xl leading-relaxed">
                Building modern web applications with passion for clean code, 
                innovative solutions, and cutting-edge technologies. Currently pursuing 
                Information Science Engineering with a focus on full-stack development.
              </p>
              
              {/* Download Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-accent hover:bg-accent-light shadow-glow btn-glow"
                  onClick={handleDownloadResume}
                  icon={<FileText size={20} />}
                >
                  Download Resume
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={handleDownloadCertificates}
                  icon={<Award size={20} />}
                >
                  Download Certificates
                </Button>
              </div>
            </div>
            
            {/* Profile Image with Flip Effect */}
            <div className="flex justify-center lg:justify-end fade-in-up">
              <div className="flip-card w-80 h-80 md:w-96 md:h-96">
                <div className="flip-card-inner">
                  <div className="flip-card-front">
                    <div className="relative w-full h-full">
                      <div className="absolute inset-0 bg-gradient-accent rounded-full opacity-30 blur-3xl scale-110"></div>
                      <div className="relative bg-gradient-card rounded-full p-6 shadow-xl w-full h-full border-2 border-accent/30">
                        <img 
                          src={vikramProfile} 
                          alt="Vikram Shetty - Professional Photo"
                          className="w-full h-full object-cover rounded-full border-4 border-accent/40 shadow-glow"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flip-card-back">
                    <div className="relative w-full h-full bg-gradient-card rounded-full p-8 shadow-xl border-4 border-primary/20 flex items-center justify-center">
                      <div className="text-center space-y-4">
                        <h3 className="text-2xl font-bold text-primary">Vikram Shetty</h3>
                        <p className="text-muted-foreground">MERN Stack Developer</p>
                        <div className="space-y-2 text-sm">
                          <p className="text-accent">🎓 ISE Student</p>
                          <p className="text-accent">💻 Full Stack Engineer</p>
                          <p className="text-accent">🚀 Tech Enthusiast</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-accent rounded-full flex justify-center">
          <div className="w-1 h-3 bg-accent rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;