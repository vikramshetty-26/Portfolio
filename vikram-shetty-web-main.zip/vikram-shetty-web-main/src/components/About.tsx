const About = () => {
  return (
    <section id="about" className="py-20 bg-gradient-subtle">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          
          {/* Section Header */}
          <div className="fade-in-up mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              About <span className="gradient-text">Me</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-accent mx-auto rounded-full"></div>
          </div>
          
          {/* Content */}
          <div className="fade-in-up">
            <div className="bg-card rounded-2xl p-8 md:p-12 shadow-lg border border-border">
              <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
                To work in an environment which encourages me to succeed and grow 
                professionally where I can utilize my skills and knowledge appropriately 
                for the success of the organization.
              </p>
              
              <div className="grid md:grid-cols-3 gap-8 mt-12">
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent">2026</div>
                  <div className="text-sm text-muted-foreground">Expected Graduation</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent">5+</div>
                  <div className="text-sm text-muted-foreground">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent">4</div>
                  <div className="text-sm text-muted-foreground">Certifications</div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};

export default About;