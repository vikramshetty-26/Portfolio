import { Trophy, Award, Users, Calendar } from 'lucide-react';

const Achievements = () => {
  const achievements = [
    {
      title: "YIASCOM PROJECT OMEGA 2025",
      description: "Secured 6th place in National Level Hackathon",
      type: "Hackathon",
      icon: <Trophy className="w-8 h-8 text-yellow-500" />,
      color: "border-yellow-200 bg-yellow-50/50"
    },
    {
      title: "College Volleyball Tournament",
      description: "Successfully coordinated and organized the tournament",
      type: "Leadership",
      icon: <Users className="w-8 h-8 text-blue-500" />,
      color: "border-blue-200 bg-blue-50/50"
    }
  ];

  const trainings = [
    {
      title: "Acdemor Learner",
      description: "Cloud Computing with Azure",
      period: "2023-2024",
      type: "Cloud Computing"
    },
    {
      title: "Java Training",
      institution: "IIT Bombay",
      type: "Programming"
    },
    {
      title: "Python 3.4 Training", 
      institution: "IIT Bombay",
      type: "Programming"
    },
    {
      title: "LaTeX Training",
      institution: "IIT Bombay", 
      type: "Documentation"
    },
    {
      title: "Microsoft Cloud Computing",
      description: "Advanced cloud technologies and services",
      type: "Cloud"
    }
  ];

  const languages = ["English", "Hindi", "Kannada", "Tulu"];
  const interests = ["Volleyball", "Kabaddi", "Cricket", "Table Tennis", "Badminton", "Singing", "Acting"];

  return (
    <section id="achievements" className="py-20 bg-gradient-subtle">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          
          {/* Section Header */}
          <div className="text-center fade-in-up mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Achievements & <span className="gradient-text">Experience</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-accent mx-auto rounded-full"></div>
          </div>
          
          {/* Achievements */}
          <div className="fade-in-up mb-16">
            <h3 className="text-2xl font-semibold mb-8 text-center">Key Achievements</h3>
            <div className="grid md:grid-cols-2 gap-8">
              {achievements.map((achievement, index) => (
                <div 
                  key={index}
                  className={`bg-card rounded-xl p-6 shadow-lg border-2 card-hover ${achievement.color}`}
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-background rounded-lg shadow-sm">
                      {achievement.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">
                          {achievement.type}
                        </span>
                      </div>
                      <h4 className="text-lg font-semibold text-foreground mb-2">
                        {achievement.title}
                      </h4>
                      <p className="text-muted-foreground text-sm">
                        {achievement.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Training & Certifications */}
          <div className="fade-in-up mb-16">
            <h3 className="text-2xl font-semibold mb-8 text-center">Training & Certifications</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trainings.map((training, index) => (
                <div 
                  key={index}
                  className="bg-card rounded-lg p-4 shadow-md border border-border card-hover"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <Award className="w-5 h-5 text-accent" />
                    <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-full font-medium">
                      {training.type}
                    </span>
                  </div>
                  <h4 className="font-semibold text-foreground mb-1">
                    {training.title}
                  </h4>
                  {training.institution && (
                    <p className="text-sm text-muted-foreground mb-2">
                      {training.institution}
                    </p>
                  )}
                  {training.description && (
                    <p className="text-sm text-muted-foreground mb-2">
                      {training.description}
                    </p>
                  )}
                  {training.period && (
                    <div className="flex items-center gap-1 text-xs text-accent">
                      <Calendar size={12} />
                      <span>{training.period}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Languages & Interests */}
          <div className="grid md:grid-cols-2 gap-8 fade-in-up">
            
            {/* Languages */}
            <div className="bg-card rounded-xl p-6 shadow-lg border border-border">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <div className="w-3 h-3 bg-accent rounded-full"></div>
                Languages
              </h3>
              <div className="flex flex-wrap gap-2">
                {languages.map((language, index) => (
                  <span 
                    key={index}
                    className="px-3 py-2 bg-secondary text-secondary-foreground rounded-full text-sm font-medium"
                  >
                    {language}
                  </span>
                ))}
              </div>
            </div>
            
            {/* Interests */}
            <div className="bg-card rounded-xl p-6 shadow-lg border border-border">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <div className="w-3 h-3 bg-accent rounded-full"></div>
                Interests & Hobbies
              </h3>
              <div className="flex flex-wrap gap-2">
                {interests.map((interest, index) => (
                  <span 
                    key={index}
                    className="px-3 py-2 bg-secondary text-secondary-foreground rounded-full text-sm font-medium"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>
            
          </div>
          
        </div>
      </div>
    </section>
  );
};

export default Achievements;