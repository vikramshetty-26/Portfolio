import { Heart, Github, Linkedin, Mail } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          
          {/* Main Footer Content */}
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            
            {/* Brand & Description */}
            <div className="md:col-span-2">
              <h3 className="text-2xl font-bold gradient-text mb-4">
                Vikram Shetty
              </h3>
              <p className="text-primary-foreground/80 leading-relaxed">
                Aspiring MERN Stack Developer passionate about creating innovative 
                web solutions and exploring cybersecurity. Always excited to learn 
                new technologies and collaborate on meaningful projects.
              </p>
            </div>
            
            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Connect With Me</h4>
              <div className="space-y-3">
                <a 
                  href="https://github.com/vikramshetty-26" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-200"
                >
                  <Github size={18} />
                  <span>GitHub</span>
                </a>
                <a 
                  href="https://www.linkedin.com/in/vikram-shetty-2b87a6327" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-200"
                >
                  <Linkedin size={18} />
                  <span>LinkedIn</span>
                </a>
                <a 
                  href="mailto:shetty263e@gmail.com"
                  className="flex items-center gap-3 text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-200"
                >
                  <Mail size={18} />
                  <span>Email</span>
                </a>
              </div>
            </div>
            
          </div>
          
          {/* Bottom Bar */}
          <div className="border-t border-primary-foreground/20 pt-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <p className="text-primary-foreground/60 text-sm">
                © {currentYear} Vikram Shetty. All rights reserved.
              </p>
              <p className="flex items-center gap-2 text-primary-foreground/60 text-sm">
                Made with <Heart size={16} className="text-red-400" /> using React & Tailwind CSS
              </p>
            </div>
          </div>
          
        </div>
      </div>
    </footer>
  );
};

export default Footer;