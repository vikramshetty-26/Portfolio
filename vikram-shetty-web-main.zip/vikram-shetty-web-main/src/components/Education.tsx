import { GraduationCap, Calendar } from 'lucide-react';

const Education = () => {
  const educationData = [
    {
      degree: "Bachelor of Engineering in Information Science and Engineering",
      institution: "Yenepoya Institute of Technology",
      year: "2026",
      grade: "7.4 CGPA",
      status: "Current"
    },
    {
      degree: "PCMC (Pre-University Course)",
      institution: "Harish PU College, Mudigere",
      year: "2022",
      grade: "79.33%",
      status: "Completed"
    },
    {
      degree: "SSLC (Secondary School Leaving Certificate)",
      institution: "St Marthas High School Mudigere",
      year: "2020",
      grade: "84.12%",
      status: "Completed"
    }
  ];

  return (
    <section id="education" className="py-20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          
          {/* Section Header */}
          <div className="text-center fade-in-up mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="gradient-text">Education</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-accent mx-auto rounded-full"></div>
          </div>
          
          {/* Timeline */}
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 h-full w-0.5 bg-gradient-accent"></div>
            
            {educationData.map((edu, index) => (
              <div 
                key={index} 
                className={`relative flex items-center mb-12 fade-in-up ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Timeline Dot */}
                <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-4 h-4 bg-accent rounded-full border-4 border-background shadow-lg z-10"></div>
                
                {/* Content Card */}
                <div className={`ml-12 md:ml-0 ${index % 2 === 0 ? 'md:mr-auto md:pr-8' : 'md:ml-auto md:pl-8'} md:w-1/2`}>
                  <div className="bg-card rounded-xl p-6 shadow-lg border border-border card-hover">
                    <div className="flex items-center gap-2 mb-3">
                      <GraduationCap className="text-accent" size={20} />
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        edu.status === 'Current' 
                          ? 'bg-accent text-accent-foreground' 
                          : 'bg-secondary text-secondary-foreground'
                      }`}>
                        {edu.status}
                      </span>
                    </div>
                    
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {edu.degree}
                    </h3>
                    
                    <p className="text-muted-foreground mb-3">
                      {edu.institution}
                    </p>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-1 text-accent">
                        <Calendar size={16} />
                        <span>{edu.year}</span>
                      </div>
                      <div className="font-semibold text-accent">
                        {edu.grade}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
        </div>
      </div>
    </section>
  );
};

export default Education;