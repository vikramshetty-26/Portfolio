import { ExternalLink, Github, Database, Shield, Brain, Heart } from 'lucide-react';
import Button from './Button';

const Projects = () => {
  const projects = [
    {
      title: "Phishing Link Detector",
      description: "Machine learning-based system to detect and classify phishing URLs using advanced NLP techniques and scikit-learn algorithms.",
      technologies: ["Python", "Scikit-Learn", "NLP", "Machine Learning"],
      icon: <Shield className="w-6 h-6 text-red-500" />,
      color: "border-red-200 hover:border-red-300"
    },
    {
      title: "Hostel Leave Management System", 
      description: "Comprehensive web application for managing student leave requests with admin approval workflow and tracking system.",
      technologies: ["HTML", "CSS", "JavaScript", "SQL"],
      icon: <Database className="w-6 h-6 text-blue-500" />,
      color: "border-blue-200 hover:border-blue-300"
    },
    {
      title: "Criminal Analysis System",
      description: "Database-driven application for criminal record management and analysis with secure data handling and reporting features.",
      technologies: ["PHP", "MySQL", "DBMS"],
      icon: <Database className="w-6 h-6 text-purple-500" />,
      color: "border-purple-200 hover:border-purple-300"
    },
    {
      title: "Classification of Handwritten Digits",
      description: "AI/ML project implementing digit recognition using neural networks and computer vision techniques for accurate classification.",
      technologies: ["Python", "AI/ML", "Computer Vision"],
      icon: <Brain className="w-6 h-6 text-green-500" />,
      color: "border-green-200 hover:border-green-300"
    },
    {
      title: "Health Care Management System",
      description: "Complete healthcare management solution with patient records, appointment scheduling, and medical history tracking.",
      technologies: ["PHP", "DBMS", "Web Development"],
      icon: <Heart className="w-6 h-6 text-pink-500" />,
      color: "border-pink-200 hover:border-pink-300"
    }
  ];

  return (
    <section id="projects" className="py-20">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          
          {/* Section Header */}
          <div className="text-center fade-in-up mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Featured <span className="gradient-text">Projects</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-accent mx-auto rounded-full"></div>
            <p className="text-lg text-muted-foreground mt-6 max-w-2xl mx-auto">
              Explore my portfolio of projects showcasing full-stack development, 
              machine learning, and cybersecurity implementations
            </p>
          </div>
          
          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div 
                key={index}
                className={`fade-in-up bg-card rounded-xl p-6 shadow-lg border-2 transition-all duration-300 card-hover ${project.color}`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Project Icon */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-secondary rounded-lg">
                    {project.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">
                    {project.title}
                  </h3>
                </div>
                
                {/* Description */}
                <p className="text-muted-foreground mb-6 text-sm leading-relaxed">
                  {project.description}
                </p>
                
                {/* Technologies */}
                <div className="mb-6">
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, techIndex) => (
                      <span 
                        key={techIndex}
                        className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* Action Button */}
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  icon={<ExternalLink size={16} />}
                >
                  View Project
                </Button>
              </div>
            ))}
          </div>
          
          {/* Call to Action */}
          <div className="text-center fade-in-up mt-12">
            <p className="text-muted-foreground mb-6">
              Interested in seeing more projects or collaborating?
            </p>
            <Button 
              size="lg" 
              icon={<Github size={20} />}
              onClick={() => window.open('https://github.com/vikramshetty-26', '_blank')}
            >
              View GitHub Profile
            </Button>
          </div>
          
        </div>
      </div>
    </section>
  );
};

export default Projects;