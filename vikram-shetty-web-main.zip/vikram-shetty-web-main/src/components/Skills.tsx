import { 
  Code, 
  Database, 
  Globe, 
  GitBranch, 
  Brain, 
  Shield, 
  Cloud,
  Lightbulb,
  Terminal,
  FileCode
} from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: "Programming Languages",
      icon: <Code className="w-6 h-6" />,
      skills: ["Python", "Java", "C++", "C"],
      color: "text-blue-500"
    },
    {
      title: "Web Development", 
      icon: <Globe className="w-6 h-6" />,
      skills: ["HTML", "CSS", "JavaScript", "React"],
      color: "text-green-500"
    },
    {
      title: "MERN Stack",
      icon: <FileCode className="w-6 h-6" />,
      skills: ["MongoDB", "Express.js", "React", "Node.js"],
      color: "text-accent"
    },
    {
      title: "Database Technologies",
      icon: <Database className="w-6 h-6" />,
      skills: ["SQL", "MySQL", "XAMPP", "DBMS"],
      color: "text-purple-500"
    },
    {
      title: "Development Tools",
      icon: <GitBranch className="w-6 h-6" />,
      skills: ["Git", "Prompt Engineering", "Azure"],
      color: "text-orange-500"
    },
    {
      title: "Specialized Areas",
      icon: <Brain className="w-6 h-6" />,
      skills: ["AI/ML Basics", "Cybersecurity", "Cloud Computing"],
      color: "text-red-500"
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gradient-subtle">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          
          {/* Section Header */}
          <div className="text-center fade-in-up mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Technical <span className="gradient-text">Skills</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-accent mx-auto rounded-full"></div>
            <p className="text-lg text-muted-foreground mt-6 max-w-2xl mx-auto">
              Passionate about modern technologies and constantly learning new skills
            </p>
          </div>
          
          {/* Skills Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => (
              <div 
                key={index}
                className="fade-in-up bg-card rounded-xl p-6 shadow-lg border border-border card-hover"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-2 rounded-lg bg-secondary ${category.color}`}>
                    {category.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">
                    {category.title}
                  </h3>
                </div>
                
                <div className="space-y-2">
                  {category.skills.map((skill, skillIndex) => (
                    <div 
                      key={skillIndex}
                      className="flex items-center justify-between py-2 px-3 bg-secondary/50 rounded-lg transition-all duration-200 hover:bg-secondary"
                    >
                      <span className="text-sm font-medium text-foreground">
                        {skill}
                      </span>
                      <div className="w-2 h-2 bg-accent rounded-full"></div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          
          {/* Highlight MERN Stack */}
          <div className="fade-in-up mt-12">
            <div className="bg-gradient-accent rounded-xl p-8 text-center shadow-xl">
              <h3 className="text-2xl font-bold text-accent-foreground mb-3">
                Specializing in MERN Stack Development
              </h3>
              <p className="text-accent-foreground/90 text-lg">
                Focused on building full-stack web applications with modern JavaScript technologies
              </p>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};

export default Skills;