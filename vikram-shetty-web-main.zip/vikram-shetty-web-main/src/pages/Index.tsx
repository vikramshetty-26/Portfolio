import { useEffect } from 'react';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Education from '@/components/Education';
import Skills from '@/components/Skills';
import Projects from '@/components/Projects';
import Achievements from '@/components/Achievements';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const Index = () => {
  useScrollAnimation();

  useEffect(() => {
    // Update document title and meta description
    document.title = "Vikram Shetty - MERN Stack Developer Portfolio";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Vikram Shetty - Aspiring MERN Stack Developer, Cybersecurity Enthusiast, and Cloud Learner. View my portfolio, projects, and achievements.');
    }

    // Add structured data for SEO
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "Person",
      "name": "Vikram Shetty",
      "jobTitle": "MERN Stack Developer",
      "description": "Aspiring MERN Stack Developer, Cybersecurity Enthusiast, and Cloud Learner",
      "url": window.location.href,
      "sameAs": [
        "https://github.com/vikramshetty-26",
        "https://www.linkedin.com/in/vikram-shetty-2b87a6327"
      ],
      "email": "shetty263e@gmail.com",
      "telephone": "+919008641682"
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(structuredData);
    document.head.appendChild(script);

    return () => {
      // Cleanup structured data on unmount
      document.head.removeChild(script);
    };
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <main>
        <Hero />
        <About />
        <Education />
        <Skills />
        <Projects />
        <Achievements />
        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
